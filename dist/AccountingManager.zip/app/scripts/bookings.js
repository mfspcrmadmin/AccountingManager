(function (global) {
  var ns = global.AccountingManagerApp = global.AccountingManagerApp || {};

  ns.createBookingsModule = function (deps) {
    var MODULES = deps.MODULES;
    var FIELD_CANDIDATES = deps.FIELD_CANDIDATES;
    var BOOKING_STAGE_FILTER_OPTIONS = deps.BOOKING_STAGE_FILTER_OPTIONS;
    var BOOKING_BROWSER_PAGE_FIELDS = deps.BOOKING_BROWSER_PAGE_FIELDS;
    var SYNC_PROJECT_FROM_EZUS_FUNCTION = deps.SYNC_PROJECT_FROM_EZUS_FUNCTION;
    var RECALCULATE_SUPPLIER_SETTLEMENTS_FOR_BOOKING_FUNCTION = deps.RECALCULATE_SUPPLIER_SETTLEMENTS_FOR_BOOKING_FUNCTION;
    var state = deps.state;
    var elements = deps.elements;
    var helpers = deps.helpers;
    var crm = deps.crm;
    var renderer = deps.renderer;
    var renderAll = deps.renderAll;
    var debugError = deps.debugError;
    var resolveFieldApiByCandidates = deps.resolveFieldApiByCandidates;
    var getFunctionOutputObject = deps.getFunctionOutputObject;
    var getFunctionResponseResult = deps.getFunctionResponseResult;
    var cloneFilterState = deps.cloneFilterState;
    var getNormalizedBookingStageValues = deps.getNormalizedBookingStageValues;
    var hasAllBookingStageFilterValuesSelected = deps.hasAllBookingStageFilterValuesSelected;
    var loadCoqlPage = deps.loadCoqlPage;
    var buildBookingRemoteWhereClause = deps.buildBookingRemoteWhereClause;
    var buildBookingRemoteOrderByClause = deps.buildBookingRemoteOrderByClause;
    var hydrateBookingPageRecords = deps.hydrateBookingPageRecords;
    var canUseBookingSearchFallback = deps.canUseBookingSearchFallback;
    var loadBookingSearchFallbackPage = deps.loadBookingSearchFallbackPage;
    var buildRemotePageSummary = deps.buildRemotePageSummary;
    var getFriendlyLoadErrorMessage = deps.getFriendlyLoadErrorMessage;
    var getCurrentUserEmail = deps.getCurrentUserEmail;
    var openAgentCommissionInvoice = deps.openAgentCommissionInvoice;

    var agentCommissionBookingId = "";

    function setAgentCommissionPopup(isOpen, message, canRecalculate, messageTone) {
      if (!elements.agentCommissionPopup) {
        return;
      }

      elements.agentCommissionPopup.hidden = !isOpen;
      if (elements.agentCommissionMessage) {
        elements.agentCommissionMessage.textContent = message || "";
        elements.agentCommissionMessage.classList.toggle("is-error", messageTone === "error");
      }
      if (elements.agentCommissionRecalculate) {
        elements.agentCommissionRecalculate.hidden = !canRecalculate;
        elements.agentCommissionRecalculate.disabled = false;
        elements.agentCommissionRecalculate.textContent = "Recalculate settlements";
      }
    }

    async function findAgentCommissionSettlement(bookingId) {
      var settlements = await crm.searchRecord(MODULES.settlements, "(Booking:equals:" + helpers.escapeCriteriaValue(bookingId) + ")");

      return (settlements || []).filter(function (settlement) {
        return helpers.normalizeString(settlement && settlement.Settlement_Type) === "agentcommission";
      })[0] || null;
    }

    function getAgentCommissionRecalculationResult(recalculationOutput) {
      var commissionResult = recalculationOutput && recalculationOutput.agent_commission;

      if (typeof commissionResult === "string") {
        try {
          commissionResult = JSON.parse(commissionResult);
        } catch (error) {
          commissionResult = null;
        }
      }

      return commissionResult && typeof commissionResult === "object" ? commissionResult : null;
    }

    function getAgentCommissionSettlementId(recalculationOutput) {
      var commissionResult = getAgentCommissionRecalculationResult(recalculationOutput);

      return String(commissionResult && commissionResult.settlement_id || "").trim();
    }

    function getAgentCommissionRecalculationError(recalculationOutput) {
      var commissionResult = getAgentCommissionRecalculationResult(recalculationOutput);

      if (!commissionResult || commissionResult.error !== true) {
        return "";
      }

      return String(commissionResult.message || "The agent commission settlement could not be recalculated.").trim();
    }

    async function findRecalculatedAgentCommissionSettlement(recalculationOutput, bookingId) {
      var settlementId = getAgentCommissionSettlementId(recalculationOutput);
      var settlement;

      // The Deluge function returns the record ID it has just created or updated.
      // Use it first: criteria searches can lag briefly behind a CRM write.
      if (settlementId) {
        settlement = await crm.getRecord(MODULES.settlements, settlementId);
        if (settlement) {
          return settlement;
        }
      }

      return findAgentCommissionSettlement(bookingId);
    }

    function onBookingsStageToggleClick(event) {
      event.preventDefault();
      state.views.bookings.stageDropdownOpen = !state.views.bookings.stageDropdownOpen;
      renderAll();
    }

    function onBookingsStageOptionChange(event) {
      var target = event.target;
      var stageValue;
      var nextValues;

      if (!target || target.type !== "checkbox") {
        return;
      }

      stageValue = target.getAttribute("data-booking-stage-value");

      if (!stageValue) {
        return;
      }

      nextValues = getNormalizedBookingStageValues(state.views.bookings.filters.stageValues);

      if (target.checked) {
        nextValues.push(stageValue);
      } else {
        nextValues = nextValues.filter(function (value) {
          return value !== stageValue;
        });
      }

      state.views.bookings.filters.stageValues = getNormalizedBookingStageValues(nextValues);
      renderAll();
    }

    function onBookingsStageMenuActionClick(event) {
      var action = event.target && event.target.getAttribute("data-booking-stage-action");

      if (!action) {
        return;
      }

      if (action === "select-all") {
        state.views.bookings.filters.stageValues = BOOKING_STAGE_FILTER_OPTIONS.slice();
      } else if (action === "clear-all") {
        state.views.bookings.filters.stageValues = [];
      }

      renderAll();
    }

    function onDocumentClickCloseBookingsStageDropdown(event) {
      if (!state.views.bookings.stageDropdownOpen) {
        return;
      }

      if (
        elements.bookingsFilterStageField &&
        event.target &&
        typeof elements.bookingsFilterStageField.contains === "function" &&
        elements.bookingsFilterStageField.contains(event.target)
      ) {
        return;
      }

      state.views.bookings.stageDropdownOpen = false;
      renderAll();
    }

    function onBookingActionsToggleClick(event) {
      if (event) {
        event.preventDefault();
        event.stopPropagation();
      }

      setBookingActionsPopupOpen(
        !elements.bookingActionsShortcut ||
        elements.bookingActionsShortcut.hidden
      );
    }

    function onDocumentClickCloseBookingActionsPopup(event) {
      if (!elements.bookingActionsShortcut || elements.bookingActionsShortcut.hidden) {
        return;
      }

      if (
        elements.bookingActionsShortcut &&
        event.target &&
        typeof elements.bookingActionsShortcut.contains === "function" &&
        elements.bookingActionsShortcut.contains(event.target)
      ) {
        return;
      }

      setBookingActionsPopupOpen(false);
    }

    function onDocumentKeydownCloseBookingActionsPopup(event) {
      if (event && event.key === "Escape") {
        setBookingActionsPopupOpen(false);
        closeBookingClosure();
      }
    }

    function setBookingActionsPopupOpen(isOpen) {
      if (!elements.bookingActionsShortcut || !elements.bookingActionsPopup || !elements.bookingActionsToggle) {
        return;
      }

      if (isOpen) {
        elements.bookingActionsShortcut.hidden = false;
        global.requestAnimationFrame(function () {
          elements.bookingActionsShortcut.classList.add("is-open");
        });
      } else {
        elements.bookingActionsShortcut.classList.remove("is-open");
        global.setTimeout(function () {
          if (!elements.bookingActionsShortcut.classList.contains("is-open")) {
            elements.bookingActionsShortcut.hidden = true;
          }
        }, 240);
      }
      elements.bookingActionsToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");

      if (isOpen && elements.bookingActionsMfsp && typeof elements.bookingActionsMfsp.focus === "function") {
        global.setTimeout(function () {
          elements.bookingActionsMfsp.focus();
        }, 0);
      }
    }

    function setBookingShortcutBusyState(isBusy, actionKey) {
      var syncLabel = "Sync project";
      var recalculateLabel = "Recalculate settlement";

      if (elements.bookingActionsMfsp) {
        elements.bookingActionsMfsp.disabled = Boolean(isBusy);
      }

      if (elements.bookingActionsSyncProject) {
        elements.bookingActionsSyncProject.disabled = Boolean(isBusy);
        elements.bookingActionsSyncProject.textContent = isBusy && actionKey === "sync"
          ? "Syncing project..."
          : syncLabel;
      }

      if (elements.bookingActionsRecalculateSettlement) {
        elements.bookingActionsRecalculateSettlement.disabled = Boolean(isBusy);
        elements.bookingActionsRecalculateSettlement.textContent = isBusy && actionKey === "recalculate"
          ? "Recalculating..."
          : recalculateLabel;
      }

      if (elements.bookingActionsTripClosure) {
        elements.bookingActionsTripClosure.disabled = Boolean(isBusy);
      }
    }

    function getBookingShortcutMfspValue() {
      return elements.bookingActionsMfsp && elements.bookingActionsMfsp.value
        ? String(elements.bookingActionsMfsp.value).trim()
        : "";
    }

    function getBookingShortcutDisplayName(bookingRecord, fallbackMfsp) {
      return helpers.getCandidateValue(bookingRecord, FIELD_CANDIDATES.booking.name) ||
        helpers.getCandidateValue(bookingRecord, FIELD_CANDIDATES.booking.mfsp) ||
        String(fallbackMfsp || "").trim() ||
        "booking";
    }

    async function resolveBookingShortcutRecordByMfsp(mfspCode) {
      var normalizedMfsp = String(mfspCode || "").trim();
      var mfspFieldApi;
      var criteria;
      var matchedRecords;
      var exactMatches;
      var resolvedRecord;

      if (!normalizedMfsp) {
        throw new Error("Enter an MFSP reference.");
      }

      mfspFieldApi = await resolveFieldApiByCandidates(
        MODULES.bookings,
        FIELD_CANDIDATES.booking.mfsp,
        "MFSP_Reference"
      );
      criteria = "(" + mfspFieldApi + ":equals:" + helpers.escapeCriteriaValue(normalizedMfsp) + ")";
      matchedRecords = await crm.searchRecord(MODULES.bookings, criteria);
      exactMatches = matchedRecords.filter(function (record) {
        var candidateValue = record
          ? record[mfspFieldApi] || helpers.getCandidateValue(record, FIELD_CANDIDATES.booking.mfsp)
          : "";

        return helpers.normalizeQuery(candidateValue) === helpers.normalizeQuery(normalizedMfsp);
      });

      if (!exactMatches.length) {
        throw new Error("No booking was found for MFSP " + normalizedMfsp + ".");
      }

      if (exactMatches.length > 1) {
        throw new Error("More than one booking was found for MFSP " + normalizedMfsp + ".");
      }

      resolvedRecord = await crm.getRecord(MODULES.bookings, exactMatches[0].id);

      if (!resolvedRecord || !resolvedRecord.id) {
        throw new Error("The booking could not be loaded for MFSP " + normalizedMfsp + ".");
      }

      return resolvedRecord;
    }

    async function onBookingSyncProjectClick() {
      var mfspCode = getBookingShortcutMfspValue();
      var bookingRecord;
      var bookingLabel;
      var bookingId;
      var syncActionUserEmail;
      var response;
      var output;
      var result;

      renderer.showError("");
      setBookingShortcutBusyState(true, "sync");
      renderer.setLoading(true, "Syncing booking project...");

      try {
        bookingRecord = await resolveBookingShortcutRecordByMfsp(mfspCode);
        bookingLabel = getBookingShortcutDisplayName(bookingRecord, mfspCode);
        bookingId = String(bookingRecord.id || "").trim();

        syncActionUserEmail = await getCurrentUserEmail();
        response = await crm.executeFunction(SYNC_PROJECT_FROM_EZUS_FUNCTION, {
          bookingId: bookingId,
          args: JSON.stringify({
            sync: {
              syncActionUserEmail: syncActionUserEmail
            }
          })
        });
        output = getFunctionOutputObject(response) || {};
        result = getFunctionResponseResult(response);

        if (output.error === true || output.success === false || result.success === false) {
          throw new Error(output.message || result.message || "The booking project could not be synced.");
        }

        renderer.showNotice(output.message || result.message || ("Project synced for " + bookingLabel + "."), {
          tone: "success"
        });
      } catch (error) {
        debugError("onBookingSyncProjectClick failed", error, {
          functionName: SYNC_PROJECT_FROM_EZUS_FUNCTION,
          mfspCode: mfspCode
        });
        renderer.showNotice("");
        renderer.showError(error.message || "Could not sync the booking project.");
      } finally {
        renderer.setLoading(false);
        setBookingShortcutBusyState(false);
      }
    }

    async function onBookingRecalculateSettlementClick() {
      var mfspCode = getBookingShortcutMfspValue();
      var bookingRecord;
      var bookingLabel;
      var response;
      var output;
      var result;

      renderer.showError("");
      setBookingShortcutBusyState(true, "recalculate");
      renderer.setLoading(true, "Recalculating supplier settlements...");

      try {
        bookingRecord = await resolveBookingShortcutRecordByMfsp(mfspCode);
        bookingLabel = getBookingShortcutDisplayName(bookingRecord, mfspCode);
        response = await crm.executeFunction(RECALCULATE_SUPPLIER_SETTLEMENTS_FOR_BOOKING_FUNCTION, {
          bookingId: String(bookingRecord.id || "").trim()
        });
        output = getFunctionOutputObject(response) || {};
        result = getFunctionResponseResult(response);

        if (output.error === true || output.success === false || result.success === false) {
          throw new Error(output.message || result.message || "Supplier settlements could not be recalculated.");
        }

        renderer.showNotice(output.message || result.message || ("Supplier settlements recalculated for " + bookingLabel + "."), {
          tone: "success"
        });
      } catch (error) {
        debugError("onBookingRecalculateSettlementClick failed", error, {
          functionName: RECALCULATE_SUPPLIER_SETTLEMENTS_FOR_BOOKING_FUNCTION,
          mfspCode: mfspCode
        });
        renderer.showNotice("");
        renderer.showError(error.message || "Could not recalculate supplier settlements.");
      } finally {
        renderer.setLoading(false);
        setBookingShortcutBusyState(false);
      }
    }

    async function onBookingRowActionClick(action, bookingId, mfspCode) {
      if (action === "trip-closure") {
        return onBookingTripClosureClick(mfspCode);
      }

      if (action !== "pay-agent-commission") {
        return;
      }

      if (!bookingId) {
        setAgentCommissionPopup(true, "This booking does not have an ID, so its agent commission cannot be registered.", false);
        return;
      }

      agentCommissionBookingId = String(bookingId).trim();
      setAgentCommissionPopup(true, "Checking the agent commission settlement...", false);

      try {
        var settlement = await findAgentCommissionSettlement(agentCommissionBookingId);

        if (!settlement) {
          setAgentCommissionPopup(true, "No agent commission settlement was found for this booking. Recalculate settlements to create it.", true);
          return;
        }

        await openAgentCommissionInvoice(settlement);
        setAgentCommissionPopup(false, "", false);
      } catch (error) {
        debugError("onBookingRowActionClick failed", error, {
          action: action,
          bookingId: bookingId
        });
        setAgentCommissionPopup(true, error.message || "Could not check the agent commission settlement.", false);
      }
    }

    async function onAgentCommissionRecalculateClick() {
      var response;
      var output;
      var result;
      var settlement;
      var agentCommissionError;
      var stage = "recalculate-settlements";

      if (!agentCommissionBookingId) {
        setAgentCommissionPopup(true, "This booking is no longer available. Close this window and try again.", false);
        return;
      }

      if (elements.agentCommissionRecalculate) {
        elements.agentCommissionRecalculate.disabled = true;
        elements.agentCommissionRecalculate.textContent = "Recalculating...";
      }
      if (elements.agentCommissionMessage) {
        elements.agentCommissionMessage.textContent = "Recalculating settlements...";
      }

      try {
        response = await crm.executeFunction(RECALCULATE_SUPPLIER_SETTLEMENTS_FOR_BOOKING_FUNCTION, {
          bookingId: agentCommissionBookingId
        });
        output = getFunctionOutputObject(response) || {};
        result = getFunctionResponseResult(response);

        if (output.error === true || output.success === false || result.success === false) {
          throw new Error(output.message || result.message || "Settlements could not be recalculated.");
        }

        stage = "validate-agent-commission";
        agentCommissionError = getAgentCommissionRecalculationError(output);
        if (agentCommissionError) {
          throw new Error(agentCommissionError);
        }

        stage = "load-agent-commission-settlement";
        settlement = await findRecalculatedAgentCommissionSettlement(output, agentCommissionBookingId);
        if (!settlement) {
          setAgentCommissionPopup(true, "The agent commission settlement is still missing after recalculation. There is another problem with this booking; please review its agent, agency and commission data.", false);
          return;
        }

        stage = "open-agent-commission-invoice";
        await openAgentCommissionInvoice(settlement);
        setAgentCommissionPopup(false, "", false);
      } catch (error) {
        debugError("onAgentCommissionRecalculateClick failed", error, {
          bookingId: agentCommissionBookingId,
          functionName: RECALCULATE_SUPPLIER_SETTLEMENTS_FOR_BOOKING_FUNCTION,
          stage: stage,
          functionResponse: response || null,
          agentCommissionResult: getAgentCommissionRecalculationResult(output),
          settlementId: settlement && settlement.id || ""
        });
        setAgentCommissionPopup(true, error.message || "Settlements could not be recalculated. There is another problem with this booking.", false, "error");
      }
    }

    function closeAgentCommissionPopup() {
      agentCommissionBookingId = "";
      setAgentCommissionPopup(false, "", false);
    }

    function getClosureNumber(record, fieldName) {
      var value = Number(record && record[fieldName]);
      return Number.isFinite(value) ? value : 0;
    }

    function getClosureInvoiceTotal(invoice) {
      return Number(helpers.getInvoiceTotalAmount(invoice, FIELD_CANDIDATES)) ||
        Number(helpers.getCandidateValue(invoice, FIELD_CANDIDATES.invoice.totalPayableAmount)) || 0;
    }

    function getClosureInvoiceTypeBadge(invoice) {
      var invoiceType = helpers.textValue(helpers.getCandidateValue(invoice, FIELD_CANDIDATES.invoice.invoiceType));
      var normalizedType = String(invoiceType || "").toLowerCase();
      var tone = "is-final";

      if (normalizedType.indexOf("credit") !== -1) {
        tone = "is-credit";
      } else if (normalizedType.indexOf("proforma") !== -1) {
        tone = "is-proforma";
      } else if (normalizedType.indexOf("ticket") !== -1) {
        tone = "is-tickets";
      } else if (normalizedType.indexOf("commission") !== -1) {
        tone = "is-commission";
      }

      return '<span class="invoice-type-badge ' + tone + '">' + helpers.escapeHtml(invoiceType || "-") + "</span>";
    }

    function isNoServicesSettlement(settlement) {
      return helpers.normalizeString(helpers.textValue(settlement && settlement.Admin_Status, "")) === "noservices";
    }

    function getClosureReviewStatus(settlement) {
      return helpers.getCandidateValue(settlement, FIELD_CANDIDATES.settlement.closureReviewStatus) || "Pending review";
    }

    function getBookingClosureStatus(booking) {
      return helpers.getCandidateValue(booking, FIELD_CANDIDATES.booking.closureStatus) || "Closure Pending";
    }

    function getBookingClosureStatusTone(status) {
      var normalized = helpers.normalizeString(status);

      if (normalized.indexOf("complete") !== -1) {
        return "is-completed";
      }
      if (normalized.indexOf("reopen") !== -1) {
        return "is-reopened";
      }
      if (normalized.indexOf("blocked") !== -1) { return "is-blocked"; }
      if (normalized.indexOf("review") !== -1) { return "is-review"; }
      return "is-pending";
    }

    function closureProgress(settlements) {
      var relevant = settlements.filter(function (item) { return !isNoServicesSettlement(item); });
      var reviewed = relevant.filter(function (item) { return helpers.normalizeString(getClosureReviewStatus(item)) === "reviewed"; }).length;
      return { total: relevant.length, reviewed: reviewed, ready: relevant.length > 0 && reviewed === relevant.length };
    }

    async function loadAllClosureRecords(module, bookingId) {
      var records = [], page = 1, batch;
      do {
        batch = await crm.searchRecordPage(module, "(Booking:equals:" + helpers.escapeCriteriaValue(String(bookingId)) + ")", page++, 200);
        records = records.concat(batch);
      } while (batch.length === 200);
      return records;
    }

    function requireClosureWriteSuccess(response) {
      var result = response && response.data && response.data[0];
      if (!result || result.code !== "SUCCESS") {
        throw new Error(result && result.message || response && response.message || "CRM did not confirm the change.");
      }
    }

    async function saveClosureStatus(closure, status, extra) {
      var payload = Object.assign({ Closure_Status: status }, extra || {});
      requireClosureWriteSuccess(await crm.updateRecord(MODULES.bookings, closure.booking.id, payload));
      Object.assign(closure.booking, payload);
      (state.views.bookings.records || []).forEach(function (record) {
        if (String(record.id) === String(closure.booking.id)) { Object.assign(record, payload); }
      });
      renderAll();
    }

    async function refreshClosureBooking(closure) {
      var booking = await crm.getRecord(MODULES.bookings, closure.booking.id);
      if (!booking || !booking.id) { throw new Error('The booking could not be loaded. Refresh and try again.'); }
      closure.booking = booking;
    }

    async function loadClosureBlockingReason(closure) {
      if (getBookingClosureStatus(closure.booking) !== 'Closure Blocked') { return; }
      try {
        var notes = [], page = 1, batch;
        do {
          batch = await crm.getRelatedRecords(MODULES.bookings, closure.booking.id, 'Notes', page++, 200);
          notes = notes.concat(batch);
        } while (batch.length === 200);
        notes = notes.filter(function (note) { return note.Note_Title === 'Trip closure blocking reason'; })
          .sort(function (a, b) { return String(b.Created_Time || '').localeCompare(String(a.Created_Time || '')); });
        closure.savedBlockReason = notes.length ? notes[0].Note_Content : '';
      } catch (error) {
        closure.savedBlockReason = '';
      }
    }

    function closureActionIcon(action) {
      var paths = { start: '<path d="m9 5 10 7-10 7Z"/>', complete: '<path d="m5 12 4 4L19 6"/>',
        block: '<circle cx="12" cy="12" r="8"/><path d="m6 6 12 12"/>',
        reopen: '<path d="M4 10a8 8 0 1 1 2 8M4 4v6h6"/>' };
      return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">' + (paths[action] || paths.block) + '</svg>';
    }

    function closureControls(closure) {
      var status = getBookingClosureStatus(closure.booking);
      var progress = closureProgress(closure.settlements || []);
      var completed = status === 'Closure Completed';
      var blocked = status === 'Closure Blocked';
      var pending = status === 'Closure Pending';
      var busy = Boolean(closure.isSaving || closure.loadFailed);
      var reason = !progress.total ? 'No active settlements to review.' : !progress.ready ? 'Review all settlements to complete closure.' : '';
      var percent = progress.total ? Math.round(progress.reviewed / progress.total * 100) : 0;
      function button(action, label, primary, unavailable, description) {
        var saving = closure.isSaving && closure.savingAction === action;
        return '<button type="' + (action === 'block' ? 'submit' : 'button') + '" class="button ' + (primary ? 'primary' : 'secondary') +
          (action === 'block' || action === 'open-block' ? ' closure-block-action' : '') + '" data-closure-action="' + action + '"' +
          (busy || unavailable ? ' disabled' : '') + (description ? ' aria-describedby="' + description + '"' : '') +
          (action === 'open-block' ? ' aria-expanded="' + Boolean(closure.blockPopoverOpen) + '" aria-controls="closure-block-popover" aria-haspopup="dialog"' : '') +
          (saving ? ' aria-busy="true"' : '') + '>' + (action === 'cancel-block' ? '' : closureActionIcon(action)) +
          '<span>' + (saving ? 'Saving...' : label) + '</span></button>';
      }
      var actions = completed ? button('reopen', 'Reopen closure', true) : blocked ? button('start', 'Resume review', true) :
        (pending ? button('start', 'Start review', true) : '') +
        (!pending || progress.ready ? '<div class="closure-complete-control">' + button('complete', 'Complete closure', !pending && progress.ready, !progress.ready, reason ? 'closure-complete-help' : '') + '</div>' : '') +
        '<div class="closure-block-anchor">' + button('open-block', 'Block closure', false) +
        (closure.blockPopoverOpen ? '<form id="closure-block-popover" class="closure-block-popover" role="dialog" aria-labelledby="closure-block-label" novalidate>' +
          '<label id="closure-block-label" for="closure-block-reason">Blocking reason</label>' +
          '<textarea id="closure-block-reason" data-closure-block-reason rows="3" maxlength="2000" required' + (busy ? ' disabled' : '') +
          (closure.blockError ? ' aria-invalid="true" aria-describedby="closure-block-error"' : '') + '>' + helpers.escapeHtml(closure.blockReason || '') + '</textarea>' +
          (closure.blockError ? '<p id="closure-block-error" class="booking-closure-error" role="alert">' + helpers.escapeHtml(closure.blockError) + '</p>' : '') +
          '<div class="closure-block-buttons">' + button('cancel-block', 'Cancel', false) + button('block', 'Block closure', false) + '</div></form>' : '') + '</div>';
      return '<section class="booking-closure-workflow" aria-label="Closure workflow" aria-busy="' + Boolean(closure.isSaving) + '">' +
        '<div class="closure-workflow-row"><div class="closure-progress"><div class="closure-progress-copy"><strong>' + progress.reviewed + ' / ' + progress.total +
        '</strong><span>settlements reviewed</span></div><div class="closure-progress-track' + (progress.ready ? ' is-ready' : '') + '" role="progressbar" aria-label="Settlements reviewed" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' + percent +
        '" aria-valuetext="' + progress.reviewed + ' of ' + progress.total + ' settlements reviewed"><span style="width:' + percent + '%"></span></div></div>' +
        '<div class="closure-workflow-actions">' + actions + '</div></div>' +
        (!completed && !blocked && !pending && reason ? '<p id="closure-complete-help" class="closure-workflow-help">' + reason + '</p>' : '') +
        (blocked ? '<p class="closure-blocked-reason">' + closureActionIcon('block') + '<span>' + helpers.escapeHtml(closure.savedBlockReason || 'See the booking Notes for the blocking reason.') + '</span></p>' : '') +
        (closure.booking.Closure_Completed_By ? '<p class="closure-workflow-audit">Last completed by ' + helpers.escapeHtml(closure.booking.Closure_Completed_By) + ' &middot; ' + helpers.escapeHtml(closure.booking.Closure_Completed_At || '') + '</p>' : '') +
        (closure.error ? '<p class="booking-closure-error" role="alert">' + helpers.escapeHtml(closure.error) + '</p>' : '') + '</section>';
    }

    function focusClosureControl(selector) {
      var control = (elements.bookingClosureControls || elements.bookingClosureContent).querySelector(selector);
      if (control && typeof control.focus === 'function') { control.focus(); }
    }

    function closeClosureBlockPopover(returnFocus) {
      var closure = state.bookingClosure;
      if (!closure || !closure.blockPopoverOpen || closure.isSaving) { return; }
      closure.blockPopoverOpen = false;
      closure.blockError = '';
      renderBookingClosure();
      if (returnFocus) { focusClosureControl('[data-closure-action="open-block"]'); }
    }

    function onClosurePopoverDismiss(event) {
      var closure = state.bookingClosure;
      if (!closure || !closure.blockPopoverOpen) { return; }
      if (event.type === 'keydown') {
        if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); closeClosureBlockPopover(true); }
      } else if (!event.target.closest('.closure-block-anchor')) {
        closeClosureBlockPopover(false);
      }
    }

    async function onClosureStatusClick(event) {
      var target = event.target && event.target.closest('[data-closure-action]');
      var closure = state.bookingClosure;
      if (!target || target.disabled || !closure || closure.isSaving || closure.loadFailed) { return; }
      var action = target.getAttribute('data-closure-action');
      if (event.preventDefault) { event.preventDefault(); }
      if (action === 'open-block') {
        closure.blockPopoverOpen = true;
        closure.blockError = '';
        renderBookingClosure();
        focusClosureControl('[data-closure-block-reason]');
        return;
      }
      if (action === 'cancel-block') { closeClosureBlockPopover(true); return; }
      var input = (elements.bookingClosureControls || elements.bookingClosureContent).querySelector('[data-closure-block-reason]');
      closure.blockReason = input ? input.value.trim() : closure.blockReason || '';
      if (action === 'block' && !closure.blockReason) {
        closure.blockError = 'Enter a blocking reason.';
        closure.blockPopoverOpen = true;
        renderBookingClosure();
        focusClosureControl('[data-closure-block-reason]');
        return;
      }
      closure.error = '';
      closure.blockError = '';
      closure.isSaving = true;
      closure.savingAction = action;
      renderBookingClosure();
      try {
        await refreshClosureBooking(closure);
        var status = getBookingClosureStatus(closure.booking);
        if (action === 'reopen') {
          if (status !== 'Closure Completed') { throw new Error('Only a completed closure can be reopened.'); }
          await saveClosureStatus(closure, 'Closure Reopened');
        } else {
          if (status === 'Closure Completed') { throw new Error('Reopen the closure before making changes.'); }
          if (action === 'start') {
            if (status !== 'Closure Pending' && status !== 'Closure Blocked') { throw new Error('The closure is already being reviewed.'); }
            await saveClosureStatus(closure, 'Closure In Review');
          } else if (action === 'block') {
            if (!closure.blockReason) { throw new Error('Enter a blocking reason.'); }
            requireClosureWriteSuccess(await crm.insertRecord('Notes', {
              Parent_Id: closure.booking.id, '$se_module': MODULES.bookings,
              Note_Title: 'Trip closure blocking reason', Note_Content: closure.blockReason
            }));
            await saveClosureStatus(closure, 'Closure Blocked');
            closure.savedBlockReason = closure.blockReason;
            closure.blockReason = '';
            closure.blockPopoverOpen = false;
          } else if (action === 'complete') {
            if (status === 'Closure Blocked') { throw new Error('Resolve the block and resume review before completing closure.'); }
            closure.settlements = await loadAllClosureRecords(MODULES.settlements, closure.booking.id);
            if (!closureProgress(closure.settlements).ready) { throw new Error('All active settlements must be reviewed before completing closure.'); }
            var email = await getCurrentUserEmail();
            if (!email) { throw new Error('The signed-in user is unavailable. Reload before completing closure.'); }
            await saveClosureStatus(closure, 'Closure Completed', {
              Closure_Completed_By: email, Closure_Completed_At: new Date().toISOString().replace(/\.\d{3}Z$/, '+00:00')
            });
          }
        }
      } catch (error) {
        if (action === 'block') {
          closure.blockError = error.message || 'Could not block closure.';
          closure.blockPopoverOpen = true;
        } else { closure.error = error.message || 'Could not update closure status.'; }
      } finally {
        closure.isSaving = false;
        closure.savingAction = '';
        renderBookingClosure();
        focusClosureControl(closure.blockPopoverOpen ? '[data-closure-block-reason]' : '.booking-closure-workflow button:not(:disabled)');
      }
    }

    function getClosureRowColor(tone, isReviewed) {
      return isReviewed ? "reviewed" : tone === "is-ok" ? "matched" : tone === "is-alert" ? "missing" : "pending";
    }

    function compareClosureRows(left, right, sortKey, direction) {
      var leftValue = left[sortKey];
      var rightValue = right[sortKey];
      var comparison = typeof leftValue === "number" && typeof rightValue === "number"
        ? leftValue - rightValue
        : String(leftValue || "").localeCompare(String(rightValue || ""), "en", { sensitivity: "base" });

      return direction === "desc" ? -comparison : comparison;
    }

    function getClosureSortHeader(label, key, sort) {
      var isActive = sort.key === key;
      var indicator = isActive ? (sort.direction === "asc" ? " ↑" : " ↓") : "";

      return '<th><button class="booking-closure-sort' + (isActive ? " is-active" : "") + '" type="button" data-booking-closure-sort="' + key + '">' + helpers.escapeHtml(label + indicator) + "</button></th>";
    }

    function getClosureSettlementMetrics(settlement, invoices) {
      var settlementId = String(settlement && settlement.id || "");
      var relatedInvoices = (invoices || []).filter(function (invoice) {
        return helpers.getLookupId(invoice.Supplier_Settlement) === settlementId;
      });
      var quoted = getClosureNumber(settlement, "Total_Service_Cost");
      var invoiced = relatedInvoices.length
        ? relatedInvoices.reduce(function (total, invoice) { return total + getClosureInvoiceTotal(invoice); }, 0)
        : getClosureNumber(settlement, "Total_Invoice");
      var paid = getClosureNumber(settlement, "Total_Paid");
      var hasInvoice = relatedInvoices.length > 0;
      var isPaid = hasInvoice && paid >= invoiced - 0.01;
      var variance = quoted - invoiced;
      var review = getClosureReviewStatus(settlement);
      var isReviewed = helpers.normalizeString(review) === "reviewed";
      var tone = !hasInvoice ? "is-alert" : hasInvoice && isPaid && Math.abs(variance) <= 0.01 ? "is-ok" : "is-pending";
      var status = !hasInvoice ? "Invoice missing" : Math.abs(variance) > 0.01 ? "Amount differs from quote" : tone === "is-ok" ? "Matched and paid" : "Payment pending";

      return {
        supplier: settlement.Supplier_Name || helpers.getLookupName(settlement.Supplier) || settlement.Name || "-",
        quoted: quoted,
        invoiced: invoiced,
        paid: paid,
        variance: variance,
        status: status,
        review: review,
        color: getClosureRowColor(tone, isReviewed)
      };
    }

    function renderBookingClosure() {
      var closure = state.bookingClosure || {};
      var booking = closure.booking;
      var settlements = (closure.settlements || []).filter(function (settlement) {
        return !isNoServicesSettlement(settlement);
      });
      var invoices = closure.invoices || [];
      var currentSalesPrice;
      var bookingClosureStatus;
      var quotedCost;
      var invoicedCost;
      var paidCost;
      var expectedMargin;
      var actualMargin;
      var costVariance;
      var summary;
      var rows;
      var closureFilter;
      var closureSort;

      if (!elements.bookingClosurePopup) {
        return;
      }

      elements.bookingClosurePopup.hidden = !closure.isOpen;
      if (elements.bookingClosureControls) {
        elements.bookingClosureControls.hidden = !closure.isOpen || closure.isLoading || !booking;
        elements.bookingClosureControls.innerHTML = elements.bookingClosureControls.hidden ? '' : closureControls(closure);
      }
      if (elements.bookingClosureAccountingRep) {
        elements.bookingClosureAccountingRep.hidden = !closure.isOpen || closure.isLoading || !booking;
        elements.bookingClosureAccountingRep.textContent = booking
          ? "Accounting rep: " + (getBookingBrowserValue(booking, FIELD_CANDIDATES.booking.accountingRep) || "Unassigned")
          : "";
      }
      if (!closure.isOpen) {
        if (elements.bookingClosureStatus) {
          elements.bookingClosureStatus.hidden = true;
        }
        return;
      }

      if (closure.isLoading) {
        elements.bookingClosureTitle.textContent = "Trip closure";
        if (elements.bookingClosureStatus) {
          elements.bookingClosureStatus.hidden = true;
        }
        elements.bookingClosureContent.innerHTML = '<div class="empty-state">Loading booking closure data...</div>';
        return;
      }

      if (!booking) {
        elements.bookingClosureTitle.textContent = "Trip closure";
        if (elements.bookingClosureStatus) {
          elements.bookingClosureStatus.hidden = true;
        }
        elements.bookingClosureContent.innerHTML = '<div class="empty-state">No booking closure data could be loaded.</div>';
        return;
      }

      currentSalesPrice = getClosureNumber(booking, "Sales_Price_inc_Taxes");
      bookingClosureStatus = getBookingClosureStatus(booking);
      quotedCost = settlements.reduce(function (total, settlement) { return total + getClosureNumber(settlement, "Total_Service_Cost"); }, 0);
      invoicedCost = settlements.reduce(function (total, settlement) { return total + getClosureNumber(settlement, "Total_Invoice"); }, 0);
      paidCost = settlements.reduce(function (total, settlement) { return total + getClosureNumber(settlement, "Total_Paid"); }, 0);
      expectedMargin = currentSalesPrice - quotedCost;
      actualMargin = currentSalesPrice - invoicedCost;
      costVariance = quotedCost - invoicedCost;
      elements.bookingClosureTitle.textContent = "Trip closure · " + getBookingShortcutDisplayName(booking) + " (" + (helpers.getCandidateValue(booking, FIELD_CANDIDATES.booking.mfsp) || "No MFSP") + ")";

      if (elements.bookingClosureStatus) {
        elements.bookingClosureStatus.textContent = bookingClosureStatus;
        elements.bookingClosureStatus.className = "booking-closure-status " + getBookingClosureStatusTone(bookingClosureStatus);
        elements.bookingClosureStatus.hidden = false;
      }

      summary = [
        ["Sales Price now", helpers.formatCurrency(currentSalesPrice)],
        ["Balance Due Amount", helpers.formatCurrency(getClosureNumber(booking, "Balance_Amount")), getClosureNumber(booking, "Balance_Amount") === 0 ? "is-zero-balance" : "is-outstanding-balance"],
        ["Quoted cost", helpers.formatCurrency(quotedCost)],
        ["Invoiced cost", helpers.formatCurrency(invoicedCost)],
        ["Paid", helpers.formatCurrency(paidCost)],
        ["Expected margin", helpers.formatCurrency(expectedMargin)],
        ["Final margin", helpers.formatCurrency(actualMargin)],
        [costVariance >= 0 ? "Gain vs quote" : "Loss vs quote", helpers.formatCurrency(Math.abs(costVariance))]
      ];
      closureFilter = closure.filter || "all";
      closureSort = closure.sort || { key: "supplier", direction: "asc" };
      settlements = settlements.filter(function (settlement) {
        return closureFilter === "all" || getClosureSettlementMetrics(settlement, invoices).color === closureFilter;
      }).sort(function (left, right) {
        return compareClosureRows(
          getClosureSettlementMetrics(left, invoices),
          getClosureSettlementMetrics(right, invoices),
          closureSort.key,
          closureSort.direction
        );
      });
      var closureColumns = [{"key": "actions", "label": "Actions"}, {"key": "reviewToggle", "label": "Review toggle"}, {"key": "supplier", "label": "Supplier / settlement"}, {"key": "review", "label": "Closure review"}, {"key": "quoted", "label": "Quoted"}, {"key": "invoiced", "label": "Invoiced"}, {"key": "paid", "label": "Paid"}, {"key": "variance", "label": "Variance"}, {"key": "status", "label": "Invoice & payment status"}, {"key": "finalInvoiceCheck", "label": "Final invoice check"}];
      ns.tableColumns.configure("tripClosure", closureColumns, renderBookingClosure);
      var visibleClosureColumns = ns.tableColumns.visibleOrder("tripClosure");
      var closureHeaders = {
        actions: '<th aria-label="Settlement actions"></th>',
        reviewToggle: '<th class="booking-closure-review-cell" aria-label="Review"></th>',
        supplier: getClosureSortHeader("Supplier / settlement", "supplier", closureSort),
        review: getClosureSortHeader("Closure review", "review", closureSort),
        quoted: getClosureSortHeader("Quoted", "quoted", closureSort),
        invoiced: getClosureSortHeader("Invoiced", "invoiced", closureSort),
        paid: getClosureSortHeader("Paid", "paid", closureSort),
        variance: getClosureSortHeader("Variance", "variance", closureSort),
        status: getClosureSortHeader("Invoice & payment status", "status", closureSort),
        finalInvoiceCheck: '<th>Final invoice check</th>',
      };
      rows = settlements.map(function (settlement) {
        var settlementId = String(settlement.id || "");
        var relatedInvoices = invoices.filter(function (invoice) {
          return helpers.getLookupId(invoice.Supplier_Settlement) === settlementId;
        });
        var quoted = getClosureNumber(settlement, "Total_Service_Cost");
        var invoiced = relatedInvoices.length
          ? relatedInvoices.reduce(function (total, invoice) { return total + getClosureInvoiceTotal(invoice); }, 0)
          : getClosureNumber(settlement, "Total_Invoice");
        var paid = getClosureNumber(settlement, "Total_Paid");
        var hasInvoice = relatedInvoices.length > 0;
        var isPaid = hasInvoice && paid >= invoiced - 0.01;
        var variance = quoted - invoiced;
        var varianceTone = hasInvoice && variance > 0.01 ? "is-gain" : hasInvoice && variance < -0.01 ? "is-loss" : "";
        var closureReviewStatus = getClosureReviewStatus(settlement);
        var isReviewed = helpers.normalizeString(closureReviewStatus) === "reviewed";
        var isAgentCommission = helpers.normalizeString(settlement && settlement.Settlement_Type) === "agentcommission";
        var tone = !hasInvoice
          ? "is-alert"
          : hasInvoice && isPaid && Math.abs(variance) <= 0.01
          ? "is-ok"
          : "is-pending";
        var status = !hasInvoice
          ? "Invoice missing"
          : Math.abs(variance) > 0.01
          ? "Amount differs from quote"
          : tone === "is-ok"
          ? "Matched and paid"
          : "Payment pending";
        var nonFinalInvoiceCount = relatedInvoices.filter(function (invoice) {
          return String(helpers.getCandidateValue(invoice, FIELD_CANDIDATES.invoice.invoiceType) || "").trim().toLowerCase() !== "final invoice";
        }).length;
        var settlementDetail = isAgentCommission
          ? "Commission"
          : String(settlement.Service_Count || 0) + " services";

        var cells = {
          actions: '<td><details class="booking-closure-actions"><summary aria-label="Settlement actions" title="Settlement actions">&#8942;</summary><div>' +
            '<button type="button" class="button secondary" data-booking-closure-request-invoice="' + helpers.escapeHtml(settlementId) + '">Request invoice</button></div></details></td>',
          reviewToggle: '<td class="booking-closure-review-cell"><button type="button" class="booking-closure-review-button' + (isReviewed ? ' is-reviewed' : '') + '" aria-label="' + (isReviewed ? 'Mark as pending review' : 'Mark as reviewed') + '" title="' + (isReviewed ? 'Mark as pending review' : 'Mark as reviewed') + '" aria-pressed="' + isReviewed + '"' + (' data-booking-closure-review-settlement-id="' + helpers.escapeHtml(settlementId) + '"') + '><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="m5 12 4 4L19 6" /></svg></button></td>',
          supplier: '<td class="booking-closure-settlement-cell"><strong>' + helpers.escapeHtml(settlement.Supplier_Name || helpers.getLookupName(settlement.Supplier) || settlement.Name || "-") + "</strong><br><span class=\"table-inline-secondary\">" + helpers.escapeHtml(settlement.Name || "") + " · " + helpers.escapeHtml(settlementDetail) + "</span></td>",
          review: '<td><span class="status-pill ' + helpers.escapeHtml(helpers.getStatusTone(closureReviewStatus)) + (isReviewed ? " booking-closure-review-pill" : "") + '">' + helpers.escapeHtml(closureReviewStatus) + "</span></td>",
          quoted: '<td class="numeric-cell">' + helpers.escapeHtml(helpers.formatCurrency(quoted)) + "</td>",
          invoiced: '<td class="numeric-cell">' + helpers.escapeHtml(hasInvoice ? helpers.formatCurrency(invoiced) : "-") + "</td>",
          paid: '<td class="numeric-cell">' + helpers.escapeHtml(helpers.formatCurrency(paid)) + "</td>",
          variance: '<td class="numeric-cell booking-closure-variance ' + varianceTone + '">' + helpers.escapeHtml(hasInvoice ? helpers.formatCurrency(variance) : "-") + "</td>",
          status: "<td>" + helpers.escapeHtml(status) + "</td>",
          finalInvoiceCheck: '<td><span class="booking-closure-final-check ' + (hasInvoice && nonFinalInvoiceCount === 0 ? 'is-complete' : 'is-incomplete') + '">' + helpers.escapeHtml(!hasInvoice ? "No invoices" : nonFinalInvoiceCount ? nonFinalInvoiceCount + " non-final / " + relatedInvoices.length : "All final") + '</span></td>'
        };
        return '<tr class="booking-closure-row ' + tone + (isReviewed ? " is-reviewed" : "") + (isAgentCommission ? " booking-closure-agent-commission" : "") + '" data-booking-closure-settlement-id="' + helpers.escapeHtml(settlementId) + '">' + visibleClosureColumns.map(function (key) { return cells[key]; }).join("") + '<td class="table-columns-gear-cell"></td></tr>';
      }).join("");

      elements.bookingClosureContent.innerHTML =
        '<div class="booking-closure-summary">' + summary.map(function (item) {
          return '<div' + (item[2] ? ' class="' + helpers.escapeHtml(item[2]) + '"' : '') + '><span>' + helpers.escapeHtml(item[0]) + "</span><strong>" + helpers.escapeHtml(item[1]) + "</strong></div>";
        }).join("") + "</div>" +
        '<div class="booking-closure-legend"><button type="button" class="' + (closureFilter === "all" ? "is-active" : "") + '" data-booking-closure-filter="all">All</button><button type="button" class="is-ok' + (closureFilter === "matched" ? " is-active" : "") + '" data-booking-closure-filter="matched">Matched, invoiced and paid</button><button type="button" class="is-pending' + (closureFilter === "pending" ? " is-active" : "") + '" data-booking-closure-filter="pending">Payment pending or amount differs from quote</button><button type="button" class="is-alert' + (closureFilter === "missing" ? " is-active" : "") + '" data-booking-closure-filter="missing">Invoice missing</button><button type="button" class="is-reviewed' + (closureFilter === "reviewed" ? " is-active" : "") + '" data-booking-closure-filter="reviewed">Reviewed</button></div>' +
        '<div class="table-wrap booking-closure-table-wrap"><table class="results-table"><thead><tr>' + visibleClosureColumns.map(function (key) { return ns.tableColumns.resizableHeader(key, closureHeaders[key]); }).join("") + '<th class="table-columns-gear-cell">' + ns.tableColumns.button("tripClosure") + "</th></tr></thead><tbody>" +
        (rows || '<tr><td colspan="' + (visibleClosureColumns.length + 1) + '" class="table-empty">No settlements were found for this booking.</td></tr>') +
        "</tbody></table></div>";
      elements.bookingClosureContent.querySelectorAll('[data-booking-closure-review-settlement-id], [data-booking-closure-request-invoice]').forEach(function (button) {
        button.disabled = Boolean(closure.isSaving || closure.loadFailed || bookingClosureStatus === 'Closure Completed');
        if (bookingClosureStatus === 'Closure Completed') { button.title = 'Reopen closure to make changes'; }
      });
    }

    function onInvoiceRequested(settlementId) {
      var closure = state.bookingClosure;
      if (!closure) { return; }
      (closure.settlements || []).forEach(function (settlement) {
        if (String(settlement.id) === settlementId) {
          settlement.Closure_Review_Status = "Invoice Requested";
        }
      });
      if (closure.detail && closure.detail.settlement && String(closure.detail.settlement.id) === settlementId) {
        closure.detail.settlement.Closure_Review_Status = "Invoice Requested";
      }
      renderBookingClosure();
    }

    function closeBookingClosure() {
      if (state.bookingClosure.isSaving) { return; }
      state.bookingClosure.isOpen = false;
      if (state.bookingClosure.detail) {
        state.bookingClosure.detail.isOpen = false;
      }
      renderBookingClosure();
      renderBookingClosureDetail();
    }

    function renderBookingClosureDetail() {
      var detail = state.bookingClosure && state.bookingClosure.detail || {};
      var settlement = detail.settlement || {};
      var services = detail.services || [];
      var invoices = detail.invoices || [];
      var payments = detail.payments || [];

      if (!elements.bookingClosureDetailPopup) {
        return;
      }

      elements.bookingClosureDetailPopup.hidden = !detail.isOpen;
      if (!detail.isOpen) {
        return;
      }

      elements.bookingClosureDetailTitle.textContent = settlement.Supplier_Name || helpers.getLookupName(settlement.Supplier) || settlement.Name || "Settlement";
      if (detail.isLoading) {
        elements.bookingClosureDetailContent.innerHTML = '<div class="empty-state">Loading settlement details...</div>';
        return;
      }

      function renderTable(headers, rows, emptyCopy) {
        return '<div class="table-wrap"><table class="results-table mini-results-table"><thead><tr>' + headers.map(function (header) {
          return "<th>" + helpers.escapeHtml(header) + "</th>";
        }).join("") + "</tr></thead><tbody>" + (rows || '<tr><td colspan="' + headers.length + '" class="table-empty">' + helpers.escapeHtml(emptyCopy) + "</td></tr>") + "</tbody></table></div>";
      }

      elements.bookingClosureDetailContent.innerHTML =
        '<div class="booking-closure-detail-sections">' +
          '<section class="booking-closure-detail-section"><h3>Services</h3>' + renderTable(["Service Date", "Name", "Status"], services.map(function (service) {
            return "<tr><td>" + helpers.escapeHtml(helpers.formatDate(service.Service_Date)) + "</td><td>" + helpers.escapeHtml(service.Product_Description || "-") + "</td><td>" + helpers.escapeHtml(service.Status_EZUS || "-") + "</td></tr>";
          }).join(""), "No services found for this settlement.") + "</section>" +
          '<section class="booking-closure-detail-section"><h3>Invoices</h3>' + renderTable(["Invoice", "Invoice type", "Date", "Amount"], invoices.map(function (invoice) {
            return "<tr><td>" + helpers.escapeHtml(invoice.Name || "-") + "</td><td>" + getClosureInvoiceTypeBadge(invoice) + "</td><td>" + helpers.escapeHtml(helpers.formatDate(invoice.Invoice_Date)) + '</td><td class="numeric-cell">' + helpers.escapeHtml(helpers.formatCurrency(getClosureInvoiceTotal(invoice))) + "</td></tr>";
          }).join(""), "No invoices found for this settlement.") + "</section>" +
          '<section class="booking-closure-detail-section"><h3>Payments</h3>' + renderTable(["Payment", "Date", "Amount"], payments.map(function (payment) {
            payment = payment || {};
            return "<tr><td>" + helpers.escapeHtml(payment.Name || "-") + "</td><td>" + helpers.escapeHtml(helpers.formatDate(payment.Payment_Date)) + '</td><td class="numeric-cell">' + helpers.escapeHtml(helpers.formatCurrency(payment.Payment_Amount)) + "</td></tr>";
          }).join(""), "No payments found for this settlement.") + "</section>" +
        "</div>";
    }

    function closeBookingClosureDetail() {
      if (state.bookingClosure && state.bookingClosure.detail) {
        state.bookingClosure.detail.isOpen = false;
      }
      renderBookingClosureDetail();
    }

    function onBookingClosureTableControlClick(event) {
      var target = event.target && event.target.closest("[data-booking-closure-sort], [data-booking-closure-filter]");
      var sortKey;
      var filter;

      if (!target) {
        return;
      }

      sortKey = target.getAttribute("data-booking-closure-sort");
      filter = target.getAttribute("data-booking-closure-filter");

      if (sortKey) {
        state.bookingClosure.sort = state.bookingClosure.sort || { key: "supplier", direction: "asc" };
        if (state.bookingClosure.sort.key === sortKey) {
          state.bookingClosure.sort.direction = state.bookingClosure.sort.direction === "asc" ? "desc" : "asc";
        } else {
          state.bookingClosure.sort = { key: sortKey, direction: "asc" };
        }
      } else if (filter) {
        state.bookingClosure.filter = state.bookingClosure.filter === filter && filter !== "all" ? "all" : filter;
      }

      renderBookingClosure();
    }

    async function onBookingClosureSettlementClick(event) {
      var interactiveTarget = event.target && event.target.closest("button, summary, details, a, input, select, textarea");
      var row = event.target && event.target.closest("[data-booking-closure-settlement-id]");
      var settlementId = row && row.getAttribute("data-booking-closure-settlement-id");
      var settlement;
      var allocations;
      var paymentIds;

      if (interactiveTarget || !settlementId) {
        return;
      }

      settlement = (state.bookingClosure.settlements || []).filter(function (item) {
        return String(item && item.id || "") === settlementId;
      })[0];
      if (!settlement) {
        return;
      }

      state.bookingClosure.detail = { isOpen: true, isLoading: true, settlement: settlement, services: [], invoices: [], payments: [] };
      renderBookingClosureDetail();
      try {
        allocations = await crm.searchRecord(MODULES.payAllocations, "(Supplier_Settlement:equals:" + settlementId + ")");
        paymentIds = helpers.uniqueNonEmpty((allocations || []).map(function (allocation) {
          return helpers.getLookupId(allocation.Supplier_Payment);
        }));
        state.bookingClosure.detail.services = await crm.searchRecord(MODULES.bookingServices, "(Supplier_Settlement:equals:" + settlementId + ")");
        state.bookingClosure.detail.invoices = await crm.searchRecord(MODULES.invoices, "(Supplier_Settlement:equals:" + settlementId + ")");
        state.bookingClosure.detail.payments = await Promise.all(paymentIds.map(function (paymentId) {
          return crm.getRecord(MODULES.payments, paymentId);
        }));
      } catch (error) {
        debugError("onBookingClosureSettlementClick failed", error, { settlementId: settlementId });
        renderer.showError(error.message || "Could not load the settlement details.");
      } finally {
        state.bookingClosure.detail.isLoading = false;
        renderBookingClosureDetail();
      }
    }

    function onBookingClosureRefreshClick() {
      if (state.bookingClosure && state.bookingClosure.isSaving) { return; }
      var booking = state.bookingClosure && state.bookingClosure.booking;
      var mfspCode = helpers.getCandidateValue(booking, FIELD_CANDIDATES.booking.mfsp);

      if (!mfspCode) {
        renderer.showError("Could not refresh the trip closure because its MFSP reference is unavailable.");
        return;
      }

      return onBookingTripClosureClick(mfspCode);
    }

    async function onBookingClosureReviewClick(event) {
      var target = event.target && event.target.closest("[data-booking-closure-review-settlement-id]");
      var settlementId = target && target.getAttribute("data-booking-closure-review-settlement-id");

      if (!settlementId || target.disabled || state.bookingClosure.isSaving || state.bookingClosure.loadFailed) {
        return;
      }

      var settlement = (state.bookingClosure.settlements || []).find(function (record) {
        return String(record && record.id || "") === settlementId;
      });
      if (!settlement) {
        return;
      }
      var isReviewed = helpers.normalizeString(getClosureReviewStatus(settlement)) === "reviewed";
      var nextReviewStatus = isReviewed ? "Pending review" : "Reviewed";
      var closure = state.bookingClosure;

      target.disabled = true;
      closure.isSaving = true;
      closure.error = '';
      renderBookingClosure();
      try {
        await refreshClosureBooking(closure);
        if (getBookingClosureStatus(closure.booking) === 'Closure Completed') {
          throw new Error('Reopen the closure before changing settlement reviews.');
        }
        requireClosureWriteSuccess(await crm.updateRecord(MODULES.settlements, settlementId, {
          Closure_Review_Status: nextReviewStatus
        }));
        state.bookingClosure.settlements = (state.bookingClosure.settlements || []).map(function (settlement) {
          if (String(settlement && settlement.id || "") === settlementId) {
            return Object.assign({}, settlement, {
              Closure_Review_Status: nextReviewStatus
            });
          }

          return settlement;
        });
        if (!isReviewed && getBookingClosureStatus(closure.booking) === 'Closure Pending') {
          try { await saveClosureStatus(closure, 'Closure In Review'); }
          catch (error) { throw new Error('Settlement review saved, but the closure status could not advance. Use Start review. ' + error.message); }
        }
        renderer.showNotice(isReviewed ? "Settlement marked as pending review." : "Settlement marked as reviewed.", { tone: "success" });
      } catch (error) {
        closure.error = error.message;
        debugError("onBookingClosureReviewClick failed", error, { settlementId: settlementId });
        renderer.showError(error.message || "Could not update the settlement review status.");
      } finally {
        closure.isSaving = false;
        renderBookingClosure();
      }
    }

    async function onBookingTripClosureClick(mfspOverride) {
      if (state.bookingClosure && state.bookingClosure.isSaving) { return; }
      var mfspCode = String(mfspOverride || getBookingShortcutMfspValue() || "").trim();
      var bookingRecord;

      renderer.showError("");
      try {
        state.bookingClosure = {
          isOpen: true,
          isLoading: true,
          booking: null,
          settlements: [],
          invoices: [],
          filter: "all",
          sort: { key: "supplier", direction: "asc" },
          detail: { isOpen: false, isLoading: false, settlement: null, services: [], invoices: [], payments: [] }
        };
        renderBookingClosure();
        renderBookingClosureDetail();
        setBookingActionsPopupOpen(false);
        bookingRecord = await resolveBookingShortcutRecordByMfsp(mfspCode);
        state.bookingClosure.booking = bookingRecord;
        await Promise.all([
          loadClosureBlockingReason(state.bookingClosure),
          loadAllClosureRecords(MODULES.settlements, bookingRecord.id).then(function (records) {
            state.bookingClosure.settlements = records || [];
          }),
          loadAllClosureRecords(MODULES.invoices, bookingRecord.id).then(function (records) {
            state.bookingClosure.invoices = records || [];
          })
        ]);
      } catch (error) {
        debugError("onBookingTripClosureClick failed", error, { mfspCode: mfspCode });
        state.bookingClosure.loadFailed = true;
        state.bookingClosure.error = 'Could not load all closure data. Refresh before making changes.';
        renderer.showError(error.message || "Could not load the booking closure data.");
      } finally {
        state.bookingClosure.isLoading = false;
        renderBookingClosure();
      }
    }

    function getBookingBrowserValue(record, candidates) {
      var lookupValue = helpers.getLookupValue(record, candidates);

      if (lookupValue && typeof lookupValue === "object") {
        return helpers.getLookupName(lookupValue);
      }

      return helpers.getCandidateValue(record, candidates);
    }

    function getBookingBrowserNumber(record, candidates) {
      var rawValue = getBookingBrowserValue(record, candidates);
      var parsedValue;

      if (rawValue === "" || rawValue === "-") {
        return null;
      }

      parsedValue = Number(rawValue);
      return Number.isNaN(parsedValue) ? null : parsedValue;
    }

    function getBookingBrowserPercent(record, candidates) {
      var numericValue = getBookingBrowserNumber(record, candidates);

      if (numericValue === null) {
        return "-";
      }

      return String(Number(numericValue.toFixed(2))) + "%";
    }

    function sortBookingsBrowserRecords(records) {
      return records.slice().sort(function (left, right) {
        var rightDate = Date.parse(getBookingBrowserValue(right, FIELD_CANDIDATES.booking.arrivalDate) || "") || 0;
        var leftDate = Date.parse(getBookingBrowserValue(left, FIELD_CANDIDATES.booking.arrivalDate) || "") || 0;

        if (rightDate !== leftDate) {
          return rightDate - leftDate;
        }

        return getBookingBrowserValue(left, FIELD_CANDIDATES.booking.name).localeCompare(
          getBookingBrowserValue(right, FIELD_CANDIDATES.booking.name),
          "en",
          { sensitivity: "base" }
        );
      });
    }

    function buildBookingCountLabel(count, options) {
      var settings = options || {};
      var label = count + (count === 1 ? " booking" : " bookings");

      if (!settings.hasExactTotal && ((Number(settings.page) || 1) > 1 || settings.hasMore)) {
        return label + " shown";
      }

      return label;
    }

    function filterBookingsBrowserRecords(records, filters) {
      var normalizedFilters = filters || {};
      var arrivalMode = normalizedFilters.arrivalDateMode === "range" ? "range" : "single";
      var arrivalDateFrom = normalizedFilters.arrivalDateFrom || "";
      var arrivalDateTo = normalizedFilters.arrivalDateTo || "";
      var selectedStages = getNormalizedBookingStageValues(normalizedFilters.stageValues);
      var hasStageFilter = selectedStages.length > 0;

      if (!selectedStages.length) {
        return [];
      }

      return (records || []).filter(function (booking) {
        var arrivalDate = helpers.toIsoDate(getBookingBrowserValue(booking, FIELD_CANDIDATES.booking.arrivalDate));
        var stageValue = getBookingBrowserValue(booking, FIELD_CANDIDATES.booking.stage);

        if (normalizedFilters.mfsp && !helpers.matchesText(getBookingBrowserValue(booking, FIELD_CANDIDATES.booking.mfsp), normalizedFilters.mfsp)) {
          return false;
        }

        if (normalizedFilters.bookingName && !helpers.matchesText(getBookingBrowserValue(booking, FIELD_CANDIDATES.booking.name), normalizedFilters.bookingName)) {
          return false;
        }

        if (arrivalMode === "single" && arrivalDateFrom && arrivalDate !== arrivalDateFrom) {
          return false;
        }

        if (arrivalMode === "range" && !helpers.isDateInRange(arrivalDate, arrivalDateFrom, arrivalDateTo)) {
          return false;
        }

        if (normalizedFilters.agency && !helpers.matchesText(getBookingBrowserValue(booking, FIELD_CANDIDATES.booking.agency), normalizedFilters.agency)) {
          return false;
        }

        if (hasStageFilter && selectedStages.indexOf(String(stageValue || "")) === -1) {
          return false;
        }

        if (normalizedFilters.accountingRep && !helpers.matchesText(getBookingBrowserValue(booking, FIELD_CANDIDATES.booking.accountingRep), normalizedFilters.accountingRep)) {
          return false;
        }

        return true;
      });
    }

    async function loadBookingsBrowserData() {
      var options = arguments[0] || {};
      var currentFilters = cloneFilterState(options.filters || state.views.bookings.filters);
      var targetPage = Math.max(1, Number(options.page) || 1);
      var remotePage;
      var pageRecords;

      renderer.showError("");
      renderer.showNotice("Loading bookings...", {
        isLoading: true
      });
      renderer.setLoading(true, "Loading bookings...");
      renderAll();

      try {
        currentFilters.stageValues = getNormalizedBookingStageValues(currentFilters.stageValues);
        remotePage = await loadCoqlPage(MODULES.bookings, BOOKING_BROWSER_PAGE_FIELDS, {
          page: targetPage,
          perPage: state.views.bookings.perPage,
          whereClause: await buildBookingRemoteWhereClause(currentFilters),
          orderByClause: await buildBookingRemoteOrderByClause()
        });
        pageRecords = await hydrateBookingPageRecords(remotePage.records);
        state.views.bookings.records = sortBookingsBrowserRecords(pageRecords);
        state.views.bookings.page = remotePage.page;
        state.views.bookings.hasMore = remotePage.hasMore;
        state.views.bookings.countLabel = buildBookingCountLabel(pageRecords.length, {
          page: remotePage.page,
          hasMore: remotePage.hasMore,
          hasExactTotal: !remotePage.hasMore && remotePage.page <= 1
        });
        state.views.bookings.pageSummary = buildRemotePageSummary(remotePage.page, remotePage.hasMore);
        state.views.bookings.appliedFilters = cloneFilterState(currentFilters);
        state.views.bookings.hasLoaded = true;
        renderAll();
      } catch (error) {
        if (canUseBookingSearchFallback(currentFilters)) {
          try {
            remotePage = await loadBookingSearchFallbackPage(currentFilters, targetPage);
            pageRecords = await hydrateBookingPageRecords(remotePage.records);
            state.views.bookings.records = sortBookingsBrowserRecords(pageRecords);
            state.views.bookings.page = remotePage.page;
            state.views.bookings.hasMore = remotePage.hasMore;
            state.views.bookings.countLabel = buildBookingCountLabel(pageRecords.length, {
              page: remotePage.page,
              hasMore: remotePage.hasMore,
              hasExactTotal: !remotePage.hasMore && remotePage.page <= 1
            });
            state.views.bookings.pageSummary = buildRemotePageSummary(remotePage.page, remotePage.hasMore);
            state.views.bookings.appliedFilters = cloneFilterState(currentFilters);
            state.views.bookings.hasLoaded = true;
            renderAll();
          } catch (fallbackError) {
            renderer.showError(getFriendlyLoadErrorMessage("bookings", error, fallbackError.message || "Could not load bookings."));
          }
        } else {
          renderer.showError(getFriendlyLoadErrorMessage("bookings", error, "Could not load bookings."));
        }
      } finally {
        renderer.setLoading(false);
        renderer.showNotice("");
        renderAll();
      }
    }

    function buildBookingsView() {
      var records = state.views.bookings.records || [];
      var emptyMessage = state.currentTab === "bookings" && state.isLoading
        ? "Loading bookings..."
        : state.views.bookings.hasLoaded
        ? "No bookings match the loaded filters."
        : "Use the filters and click Load to fetch bookings.";

      return {
        filteredRecords: records,
        visibleRecords: records,
        countLabel: state.views.bookings.countLabel || "0 bookings",
        emptyMessage: emptyMessage,
        hasLoaded: Boolean(state.views.bookings.hasLoaded),
        page: Math.max(1, Number(state.views.bookings.page) || 1),
        hasMore: Boolean(state.views.bookings.hasMore),
        pageSummary: state.views.bookings.pageSummary || "Page 1",
        stageOptions: BOOKING_STAGE_FILTER_OPTIONS.map(function (value) {
          return {
            value: value,
            label: value
          };
        }),
        formatters: {
          text: function (record, candidates) {
            return helpers.textValue(getBookingBrowserValue(record, candidates));
          },
          date: function (record, candidates) {
            return helpers.formatDate(getBookingBrowserValue(record, candidates));
          },
          currency: function (record, candidates) {
            var numericValue = getBookingBrowserNumber(record, candidates);
            return numericValue === null ? "-" : helpers.formatCurrency(numericValue);
          },
          number: function (record, candidates) {
            var numericValue = getBookingBrowserNumber(record, candidates);
            return numericValue === null ? "-" : String(Number.isInteger(numericValue) ? numericValue : Number(numericValue.toFixed(2)));
          },
          percent: function (record, candidates) {
            return getBookingBrowserPercent(record, candidates);
          }
        }
      };
    }

    return {
      onStageToggleClick: onBookingsStageToggleClick,
      onStageOptionChange: onBookingsStageOptionChange,
      onStageMenuActionClick: onBookingsStageMenuActionClick,
      onDocumentClickCloseStageDropdown: onDocumentClickCloseBookingsStageDropdown,
      onActionsToggleClick: onBookingActionsToggleClick,
      onDocumentClickCloseActionsPopup: onDocumentClickCloseBookingActionsPopup,
      onDocumentKeydownCloseActionsPopup: onDocumentKeydownCloseBookingActionsPopup,
      setActionsPopupOpen: setBookingActionsPopupOpen,
      onSyncProjectClick: onBookingSyncProjectClick,
      onRecalculateSettlementClick: onBookingRecalculateSettlementClick,
      onRowActionClick: onBookingRowActionClick,
      onAgentCommissionRecalculateClick: onAgentCommissionRecalculateClick,
      closeAgentCommissionPopup: closeAgentCommissionPopup,
      onTripClosureClick: onBookingTripClosureClick,
      closeBookingClosure: closeBookingClosure,
      closeBookingClosureDetail: closeBookingClosureDetail,
      onClosureRefreshClick: onBookingClosureRefreshClick,
      onClosureReviewClick: onBookingClosureReviewClick,
      onClosureStatusClick: onClosureStatusClick,
      onClosurePopoverDismiss: onClosurePopoverDismiss,
      onInvoiceRequested: onInvoiceRequested,
      onClosureTableControlClick: onBookingClosureTableControlClick,
      onClosureSettlementClick: onBookingClosureSettlementClick,
      loadBrowserData: loadBookingsBrowserData,
      buildView: buildBookingsView
    };
  };
}(window));
